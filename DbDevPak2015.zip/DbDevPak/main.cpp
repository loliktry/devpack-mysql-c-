
#include <windows.h>
#include <iostream>
#include <mysql.h>
#include <stdio.h>
/*#include <stdio.h>

#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>*/
#include <iomanip>
//#include <sstream>

using namespace std;

int hidup =1;
MYSQL *sock;
struct data_mobil
{
    char nama[100];
    char harga[30];

} mobil;

//typedef struct data_mobil mobil;

void entry_data_mobil()
{
    cout << "Insert data mobil dalam database " << endl;

    /*printf("Nama \t\t\t: "); fflush(stdin);
    gets(mobil.nama);
    printf("Harga \t\t\t: "); fflush(stdin);
    gets(mobil.harga);
    */
    cout << setw(5) << "Nama \t \t : " ;
    cin >> mobil.nama;
    cout << setw(5) << "Harga \t \t :" ;
    cin >> mobil.harga;
    //insert record
    string query;

    query = std::string("INSERT INTO Cars (name, price) VALUES('") + mobil.nama + "'," + mobil.harga + ")";
    if (mysql_query(sock, query.c_str())) {
      cout << "sock handle failed!" << mysql_error(sock) << endl;
    }
}
void list_data_mobil()
{
    cout << "Daftar mobil yang telah dimasukkan dalam Database";
    if (mysql_query(sock, "SELECT * FROM Cars"))
    {
      cout << "sock handle failed!" << mysql_error(sock) << endl;
    }

    MYSQL_RES *result = mysql_store_result(sock);
    if (result == NULL)
    {
        cout << "sock handle failed!" << mysql_error(sock) << endl;
    }

    int num_fields = mysql_num_fields(result);

    MYSQL_ROW row;
    MYSQL_FIELD *field;

    while ((row = mysql_fetch_row(result)))
    {
      for(int i = 0; i < num_fields; i++)
      {
          if (i == 0)
          {
             printf("\n|");
             while(field = mysql_fetch_field(result))
             {
                printf("%s \t | ", field->name);
             }
             printf("\n");
          }
          printf("| %s \t  ", row[i] ? row[i] : "NULL");
      }
    }

    mysql_free_result(result);
    printf("\n");
}

void cari_data_mobil()
{
    char cari;
    string query;
    cout << "Pencarian Data Mobil \n";
    cout << setw(5) << "Nama \t : " ;
    cin >> cari;
    query = std::string("SELECT * FROM Cars WHERE name like '%") + cari + "%' ";
    if (mysql_query(sock, query.c_str()))
    {
      cout << "sock handle failed!" << mysql_error(sock) << endl;
    }

    MYSQL_RES *result = mysql_store_result(sock);
    if (result == NULL)
    {
        cout << "sock handle failed!" << mysql_error(sock) << endl;
    }

    int num_fields = mysql_num_fields(result);

    MYSQL_ROW row;
    MYSQL_FIELD *field;

    while ((row = mysql_fetch_row(result)))
    {
      for(int i = 0; i < num_fields; i++)
      {
          if (i == 0)
          {
             printf("\n|");
             while(field = mysql_fetch_field(result))
             {
                printf("%s \t | ", field->name);
             }
             printf("\n");
          }
          printf("| %s \t  ", row[i] ? row[i] : "NULL");
      }
    }
    if (mysql_fetch_row(result) == 0) cout << "\nTidak ada data yang sama" << endl;
    mysql_free_result(result);
    printf("\n");
}

void delete_data_mobil()
{
    cout << "\nHapus data mobil dalam Database\n";
}

int status_kehidupan(int status=1){
    if(status==0){
        mysql_close(sock);
        exit(0);
    }
    return status;
}

bool konek_ke_database(){
    //connection params
    //sock
    char *host = "localhost";
    char *user = "root";
    char *pass = "";
    char *db = "mobilDb";
    bool status;


    sock = mysql_init(0);
    if (sock) cout << "sock handle ok!" << endl;
    else {
         cout << "sock handle failed!" << mysql_error(sock) << endl;
    }

    //connection
    if (mysql_real_connect(sock, host, user, pass, db, 0, NULL, 0)){
         cout << "connection ok!" << endl;
         status = true;
    }
    else {
         cout << "connection fail: " << mysql_error(sock) << endl;
         status = false;
    }

    return status;
}

int kedatabase(){

    system("PAUSE");
    if (mysql_query(sock, "CREATE DATABASE IF NOT EXISTS testdb"))
    {
      cout << "sock handle failed!" << mysql_error(sock) << endl;
    }
    // delete table cars jika ada
    if (mysql_query(sock, "DROP TABLE IF EXISTS Cars")) {
      cout << "sock handle failed!" << mysql_error(sock) << endl;
    }
    //create table
    if (mysql_query(sock, "CREATE TABLE Cars(Id INT, Name TEXT, Price INT)")) {
      cout << "sock handle failed!" << mysql_error(sock) << endl;
    }
    //insert record
    if (mysql_query(sock, "INSERT INTO Cars VALUES(1,'Audi',52642)")) {
      cout << "sock handle failed!" << mysql_error(sock) << endl;
    }

    //closing connection
    mysql_close(sock);

    return EXIT_SUCCESS;
}
void garis1(int n)
{
    for(int i=0; i<n; i++)
    {
      cout << "*";
    }
    cout << "\n";
}

int main()
{
    if(konek_ke_database()){
        while(status_kehidupan()==1)
        {
          int input;
          system("cls");
          garis1(79);
          cout << setw(53) << "+-------------------------+" << endl;
          cout << setw(53) << "|  ###   MENU UTAMA  ###  |" << endl;
          cout << setw(53) << "+-------------------------+" << endl;
          cout << setw(53) << "| 1. Entry Data Mobil     |" << endl;
          cout << setw(53) << "| 2. List Mobil           |" << endl;
          cout << setw(53) << "| 3. Cari Data Mobil      |" << endl;
          cout << setw(53) << "| 4. Hapus Data Mobil     |" << endl;
          cout << setw(53) << "| 5. Keluar               |" << endl;
          cout << setw(53) << "+-------------------------+" << endl << endl;
          garis1(79);
          cout << setw(47) << "Masukkan pilihan : ";
          cin >> input;
          /*cout<<"1. Create Database n Tables\n";
          cout<<"2. Insert Data to table \n";
          cout<<"3. Running App\n";
          cout<<"4. Exit\n";
          cout<<"Pilih menu : ";
          cin>> input;*/
          switch ( input ) {
              case 1:            // Note the colon, not a semicolon
                entry_data_mobil();
                //system("cls");
                system("PAUSE");
                break;
              case 2:            // Note the colon, not a semicolon
                list_data_mobil();
                system("PAUSE");
                break;
              case 3:            // Note the colon, not a semicolon
                cari_data_mobil();
                system("PAUSE");
                break;
              case 4:            // Note the colon, not a semicolon
                delete_data_mobil();
                system("PAUSE");
                break;
              case 5:
                cout<<"Terimakasih telah menggunkan aplikasi ini! Tekan Enter untuk\n";
                system("PAUSE");
                status_kehidupan(0);
                break;
              default:            // Note the colon, not a semicolon
                cout<<"Kesalahan menginputkan pilihan\n";
                break;
          }
          cin.get();
        }
    }else cout << "Aplikasi tidak terhubung dengan database!!" << endl;
}



